package ConnectionPool;


public interface IfConnection {
    public void execute();
    public void close();
}
